# Solarized Light Flavor für Yazi

Abgeleitet vom MIT-lizenzierten Flavor [peterfication/solarized.yazi](https://github.com/peterfication/solarized.yazi)
(Solarized Dark). Die Grundtöne base03–base3 sind gespiegelt, die Akzentfarben unverändert,
so wie es das Solarized-Farbschema für die helle Variante vorsieht.

## Installation

Ordner nach `~/.config/yazi/flavors/solarized-light.yazi/` kopieren und in
`~/.config/yazi/theme.toml` eintragen:

```toml
[flavor]
dark  = "solarized-light"
light = "solarized-light"
```
